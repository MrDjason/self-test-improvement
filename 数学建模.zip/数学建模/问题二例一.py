import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys
import os
import re

plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 或者 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

# ==================== 0. 控制台输出同时保存到文件（可选）====================
class Tee:
    def __init__(self, filename):
        self.file = open(filename, 'w', encoding='utf-8')
        self.stdout = sys.stdout
    def write(self, text):
        self.stdout.write(text)
        self.file.write(text)
    def flush(self):
        self.stdout.flush()
        self.file.flush()

# 启用日志保存（取消下一行注释）
# sys.stdout = Tee('oxidation_analysis_report_corrected.txt')

# ==================== 1. 数据读取与预处理 ====================
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')
df['oil_type'] = df['oil_type'].replace({'香玲': 'XL', '鲁光': 'LG', '山核桃': 'SH'})

# 关键修正：标准化化合物名称（去除空格、统一括号格式）
def standardize_compound(name):
    # 去除所有空格
    name = re.sub(r'\s+', '', name)
    # 统一括号为半角
    name = name.replace('（', '(').replace('）', ')')
    return name
df['compound'] = df['compound'].apply(standardize_compound)
df['compound_id'] = df['category'] + '_' + df['compound']

time_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
time_days = [0, 1, 2, 3, 5, 7, 10]
total_days = {'XL': 7, 'LG': 7, 'SH': 10}

all_compounds = df['compound_id'].unique()
oil_types = ['XL', 'LG', 'SH']

# 构建时间序列数据字典
data = {p: {cid: [] for cid in all_compounds} for p in oil_types}
for p in oil_types:
    sub = df[df['oil_type'] == p]
    for _, row in sub.iterrows():
        cid = row['compound_id']
        series = []
        for col, day in zip(time_cols, time_days):
            if day <= total_days[p]:
                val = row[col]
                if pd.isna(val):
                    val = 0.0
                series.append(float(val))
        data[p][cid] = series

# 补齐缺失化合物序列（全0）
for p in oil_types:
    n = len([d for d in time_days if d <= total_days[p]])
    for cid in all_compounds:
        if len(data[p][cid]) != n:
            data[p][cid] = [0.0] * n

time_points = {p: [d for d in time_days if d <= total_days[p]] for p in oil_types}

# ==================== 2. 辅助函数 ====================
def monotonic_trend(series, start, end):
    inc = all(series[i+1] >= series[i] for i in range(len(series)-1))
    dec = all(series[i+1] <= series[i] for i in range(len(series)-1))
    if inc and end > start:
        return 1
    elif dec and end < start:
        return -1
    else:
        return 0

def compute_features(series, times, total_days):
    start = series[0]
    end = series[-1]
    delta = end - start
    avg_daily = delta / total_days
    peak = max(series)
    peak_idx = series.index(peak)
    peak_time = times[peak_idx]
    final_amp = end / (start + 1e-9)
    peak_amp = peak / (start + 1e-9)
    M = monotonic_trend(series, start, end)
    return {
        'start': start, 'end': end, 'delta': delta, 'avg_daily': avg_daily,
        'peak': peak, 'peak_time': peak_time, 'final_amp': final_amp,
        'peak_amp': peak_amp, 'M': M
    }

def growth_efficiency(series, times, total_days):
    if len(series) < 2:
        return 0.0
    sum_rel = 0.0
    for j in range(len(series)-1):
        if series[j] > 0:
            rel_growth = (series[j+1] - series[j]) / series[j]
            sum_rel += rel_growth
    return sum_rel / total_days

def min_max_normalize(x):
    """将一维数组归一化到 [0,1] 区间，处理全零情况"""
    min_x = np.min(x)
    max_x = np.max(x)
    if max_x - min_x < 1e-12:
        return np.zeros_like(x)
    return (x - min_x) / (max_x - min_x)

def entropy_weight(matrix):
    """矩阵每一列已经非负，计算熵权"""
    # 确保非负
    matrix = np.maximum(matrix, 0)
    p = matrix / (matrix.sum(axis=0, keepdims=True) + 1e-12)
    p = np.clip(p, 1e-12, 1)
    I = matrix.shape[0]
    e = -1.0 / np.log(I) * np.sum(p * np.log(p), axis=0)
    d = 1 - e
    w = d / (d.sum() + 1e-12)
    return w

# ==================== 3. 计算基础特征 ====================
features = {p: {} for p in oil_types}
for p in oil_types:
    times = time_points[p]
    T = total_days[p]
    for cid in all_compounds:
        series = data[p][cid]
        if max(series) <= 0:
            continue
        features[p][cid] = compute_features(series, times, T)

valid_compounds = set()
for p in oil_types:
    valid_compounds.update(features[p].keys())
valid_compounds = list(valid_compounds)

# ==================== 4. 计算 R_i, G_i, D_i ====================
alpha, beta, gamma = 0.4, 0.4, 0.2
R_i = {}
r_i_p = {p: {} for p in oil_types}

for p in oil_types:
    if features[p]:
        max_avg = max([features[p][cid]['avg_daily'] for cid in features[p]], default=1e-9)
        max_final = max([features[p][cid]['final_amp'] for cid in features[p]], default=1e-9)
    else:
        max_avg, max_final = 1e-9, 1e-9
    for cid in features[p]:
        f = features[p][cid]
        norm_avg = f['avg_daily'] / (max_avg + 1e-9)
        norm_final = f['final_amp'] / (max_final + 1e-9)
        mono_bonus = 1 if f['M'] == 1 else 0
        r = alpha * norm_avg + beta * norm_final + gamma * mono_bonus
        r_i_p[p][cid] = r

for cid in valid_compounds:
    vals = [r_i_p[p][cid] for p in oil_types if cid in r_i_p[p]]
    R_i[cid] = max(vals) if vals else 0.0

G_i = {}
for cid in valid_compounds:
    g_vals = []
    for p in oil_types:
        if cid in features[p]:
            series = data[p][cid]
            times = time_points[p]
            T = total_days[p]
            g = growth_efficiency(series, times, T)
            g_vals.append(g)
    G_i[cid] = max(g_vals) if g_vals else 0.0

D_i = {}
for cid in valid_compounds:
    ends = []
    for p in oil_types:
        if cid in features[p]:
            ends.append(features[p][cid]['end'])
        else:
            ends.append(0.0)
    max_end = max(ends)
    min_end = min(ends)
    D_i[cid] = (max_end - min_end) / (max_end + 1e-9)

# ==================== 5. 熵权法确定 w_R, w_G, w_D（先归一化）====================
X_raw = np.array([[R_i[cid], G_i[cid], D_i[cid]] for cid in valid_compounds])
# 对每一列进行 Min-Max 归一化
X_norm = np.apply_along_axis(min_max_normalize, 0, X_raw)
weights = entropy_weight(X_norm)
w_R, w_G, w_D = weights

Phi = {cid: w_R*R_i[cid] + w_G*G_i[cid] + w_D*D_i[cid] for cid in valid_compounds}

# ==================== 6. 动态筛选核心氧化标志物 ====================
phi_vals = np.array(list(Phi.values()))
R_vals = np.array([R_i[cid] for cid in valid_compounds])
D_vals = np.array([D_i[cid] for cid in valid_compounds])

Q_phi_70 = np.quantile(phi_vals, 0.70)
Q_R_50 = np.quantile(R_vals, 0.50)
Q_D_25 = np.quantile(D_vals, 0.25)

candidate_mask = (phi_vals >= Q_phi_70) & (R_vals > Q_R_50) & (D_vals > Q_D_25)

has_increasing = []
for cid in valid_compounds:
    inc = any(features[p][cid]['M'] == 1 for p in oil_types if cid in features[p])
    has_increasing.append(inc)
candidate_mask = candidate_mask & np.array(has_increasing)

core_markers = [valid_compounds[i] for i, flag in enumerate(candidate_mask) if flag]

# ==================== 7. 计算核心标志物的稳定性子指标（修正U负值）====================
U_dict = {p: {} for p in oil_types}
tau_dict = {p: {} for p in oil_types}
Z_dict = {p: {} for p in oil_types}

for cid in core_markers:
    # 计算该化合物在各油样中的 avg_daily 最大值（用于归一化 U）
    avg_daily_list = [features[p][cid]['avg_daily'] if cid in features[p] else 0.0 for p in oil_types]
    max_avg_daily = max(avg_daily_list) + 1e-9
    # 末期含量最大值（用于归一化 Z）
    end_list = [features[p][cid]['end'] if cid in features[p] else 0.0 for p in oil_types]
    max_end = max(end_list) + 1e-9

    for p in oil_types:
        if cid in features[p]:
            f = features[p][cid]
            # 修正：若 avg_daily 为负，则 U 设为 0
            raw_U = f['avg_daily'] / max_avg_daily
            U = max(0.0, raw_U)
            tau = f['peak_time'] / total_days[p]
            Z = f['end'] / max_end
        else:
            U, tau, Z = 0.0, 0.0, 0.0
        U_dict[p][cid] = U
        tau_dict[p][cid] = tau
        Z_dict[p][cid] = Z

# ==================== 8. 第二次熵权法（同样先归一化）====================
indicator_data = []
for p in oil_types:
    for cid in core_markers:
        # 三个正向化指标：1-U, tau, 1-Z
        val_1U = 1 - U_dict[p][cid]
        val_tau = tau_dict[p][cid]
        val_1Z = 1 - Z_dict[p][cid]
        indicator_data.append([val_1U, val_tau, val_1Z])
indicator_matrix = np.array(indicator_data)
# 归一化每一列
indicator_norm = np.apply_along_axis(min_max_normalize, 0, indicator_matrix)
lambda_weights = entropy_weight(indicator_norm)
lambda1, lambda2, lambda3 = lambda_weights

# ==================== 9. 计算 OSI ====================
OSI = {}
for p in oil_types:
    score_sum = 0.0
    for cid in core_markers:
        term = lambda1 * (1 - U_dict[p][cid]) + lambda2 * tau_dict[p][cid] + lambda3 * (1 - Z_dict[p][cid])
        score_sum += Phi[cid] * term
    OSI[p] = score_sum / len(core_markers)

# ==================== 10. 控制台详细输出 ====================
print("="*70)
print("问题二 模型求解与结果分析报告（修正版）")
print("="*70)

print("\n1. 数据预处理与基础特征统计")
print("-"*50)
print(f"有效化合物总数: {len(valid_compounds)}")
print(f"油样观测时长: 香玲(XL)={total_days['XL']}天, 鲁光(LG)={total_days['LG']}天, 山核桃(SH)={total_days['SH']}天")
print("各油样时间点: XL/LG -> 0,1,2,3,5,7天; SH -> 0,1,2,3,5,7,10天")
print("\n各油样中单调递增(M=1)的化合物数量:")
for p in oil_types:
    inc_count = sum(1 for cid in features[p] if features[p][cid]['M'] == 1)
    print(f"  {p}: {inc_count}")

print("\n基础特征示例 (前5个化合物，仅XL油样):")
sample_cids = [c for c in valid_compounds if c in features['XL']][:5]
print(f"{'化合物ID':<40} {'起始':>6} {'末期':>6} {'日均增量':>8} {'峰值时间':>6} {'单调'}")
for cid in sample_cids:
    f = features['XL'][cid]
    print(f"{cid:<40} {f['start']:6.2f} {f['end']:6.2f} {f['avg_daily']:8.4f} {f['peak_time']:6.1f} {f['M']:>3}")

print("\n2. 核心氧化标志物筛选结果")
print("-"*50)
print(f"熵权法权重 (基于 R_i, G_i, D_i):")
print(f"  w_R (时间响应强度) = {w_R:.4f}")
print(f"  w_G (增长效率)     = {w_G:.4f}")
print(f"  w_D (品种区分能力) = {w_D:.4f}")
print(f"\n综合评分 Φ 分布:")
print(f"  最小值: {np.min(phi_vals):.4f}, 最大值: {np.max(phi_vals):.4f}")
print(f"  中位数: {np.median(phi_vals):.4f}, 上四分位数: {np.quantile(phi_vals, 0.75):.4f}")
print(f"  筛选阈值(上70%分位数): {Q_phi_70:.4f}")
print(f"\n时间响应强度 R 分布: 中位数 = {np.median(R_vals):.4f}, 阈值(>中位数): {Q_R_50:.4f}")
print(f"品种区分能力 D 分布: 下四分位数 = {np.quantile(D_vals, 0.25):.4f}, 阈值(>下四分位数): {Q_D_25:.4f}")
print(f"单调递增条件: 至少在一个油样中 M=1")
print(f"\n筛选出的核心氧化标志物数量: {len(core_markers)}")

if core_markers:
    core_with_phi = [(cid, Phi[cid], R_i[cid], G_i[cid], D_i[cid]) for cid in core_markers]
    core_with_phi.sort(key=lambda x: x[1], reverse=True)
    print("\n核心氧化标志物详细列表 (按综合评分Φ降序):")
    print(f"{'序号':<4} {'化合物ID':<45} {'Φ':>9} {'R_i':>9} {'G_i':>9} {'D_i':>9} {'单调油样'}")
    for idx, (cid, phi_val, r_val, g_val, d_val) in enumerate(core_with_phi, 1):
        inc_oils = [p for p in oil_types if cid in features[p] and features[p][cid]['M'] == 1]
        inc_str = ','.join(inc_oils) if inc_oils else '无'
        print(f"{idx:<4} {cid:<45} {phi_val:9.4f} {r_val:9.4f} {g_val:9.4f} {d_val:9.4f} {inc_str}")

print("\n3. 氧化稳定性评价指标")
print("-"*50)
print(f"第二次熵权法权重 (基于 1-U, tau, 1-Z):")
print(f"  λ1 (1-日均增长速率指数) = {lambda1:.4f}")
print(f"  λ2 (相对峰值时间)       = {lambda2:.4f}")
print(f"  λ3 (1-末期相对含量)     = {lambda3:.4f}")
print("\n各油样在三个稳定性子指标上的平均值 (原始值, 未归一化):")
print(f"{'油样':<6} {'1-U (反向速率)':>18} {'tau (峰值时间)':>18} {'1-Z (反向末期)':>18}")
for p in oil_types:
    mean_1U = np.mean([1 - U_dict[p][cid] for cid in core_markers]) if core_markers else 0
    mean_tau = np.mean([tau_dict[p][cid] for cid in core_markers]) if core_markers else 0
    mean_1Z = np.mean([1 - Z_dict[p][cid] for cid in core_markers]) if core_markers else 0
    print(f"{p:<6} {mean_1U:18.4f} {mean_tau:18.4f} {mean_1Z:18.4f}")
print("\n氧化稳定性评分 (OSI) 及排名:")
sorted_osi = sorted(OSI.items(), key=lambda x: x[1], reverse=True)
for rank, (p, score) in enumerate(sorted_osi, 1):
    print(f"  第{rank}名: {p} = {score:.4f}")

print("\n4. 关键氧化标志物动态趋势 (Φ排名前3)")
print("-"*50)
top3 = sorted(core_markers, key=lambda cid: Phi[cid], reverse=True)[:3] if core_markers else []
for idx, cid in enumerate(top3, 1):
    print(f"第{idx}名: {cid}  (Φ={Phi[cid]:.4f})")
    for p in oil_types:
        if cid in features[p]:
            f = features[p][cid]
            peak_day = f['peak_time']
            end_val = f['end']
            print(f"  {p}: 峰值时间={peak_day}天, 末期含量={end_val:.2f}")
        else:
            print(f"  {p}: 未检出或始终为零")

print("\n" + "="*70)
print("模型稳健性提示：本结果已修正化合物名称标准化、熵权法前指标归一化、U负值处理。")
print("当前筛选条件: Φ≥上70%分位数, R>中位数, D>下四分位数, 且至少在一个油样中单调递增。")
print("="*70)

# ==================== 11. 可视化 ====================
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def radar_chart():
    if not core_markers:
        return
    categories = ['1-日均增长速率', '相对峰值时间', '1-末期相对含量']
    name_map = {'XL': '香玲', 'LG': '鲁光', 'SH': '山核桃'}
    colors = {'XL': '#4C72B0', 'LG': '#55A868', 'SH': '#DD8452'}
    
    avg_1U = [np.mean([1 - U_dict[p][cid] for cid in core_markers]) for p in oil_types]
    avg_tau = [np.mean([tau_dict[p][cid] for cid in core_markers]) for p in oil_types]
    avg_1Z = [np.mean([1 - Z_dict[p][cid] for cid in core_markers]) for p in oil_types]
    values = np.array([avg_1U, avg_tau, avg_1Z]).T
    for j in range(3):
        maxv = values[:, j].max()
        if maxv > 0:
            values[:, j] /= maxv
    
    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]
    
    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    for idx, p in enumerate(oil_types):
        vals = values[idx].tolist()
        vals += vals[:1]
        ax.plot(angles, vals, label=name_map[p], linewidth=2, color=colors[p])
        ax.fill(angles, vals, alpha=0.25, color=colors[p])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=11)
    ax.tick_params(axis='y', labelsize=9)
    ax.legend(loc='upper right', fontsize=10, framealpha=0.9, edgecolor='none')
    plt.title('氧化稳定性子指标雷达图', fontsize=14, pad=20)
    plt.tight_layout()
    plt.savefig('radar_chart_corrected.png', dpi=300)
    plt.show()

def bar_plot():
    plt.figure(figsize=(6, 5))
    name_map = {'XL': '香玲', 'LG': '鲁光', 'SH': '山核桃'}
    colors = {'XL': '#4C72B0', 'LG': '#55A868', 'SH': '#DD8452'}
    oils = [name_map[p] for p in OSI.keys()]
    scores = [OSI[p] for p in OSI.keys()]
    # 保持与折线图相同的颜色顺序
    bar_colors = [colors[p] for p in OSI.keys()]
    bars = plt.bar(oils, scores, color=bar_colors, width=0.6, edgecolor='white', linewidth=0.5)

    ylabel = '氧\n化\n稳\n定\n性\n指\n数\n(OSI)'
    plt.ylabel(ylabel, 
           fontsize=12, 
           labelpad=25,    # 向左移动
           rotation=0,     # 保持竖排
           va='center',    # 垂直居中
           ha='center')    # 水平居中
    plt.title('三种核桃油氧化稳定性对比', fontsize=14)
    plt.ylim(0, max(scores) * 1.1)
    for bar, score in zip(bars, scores):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f'{score:.3f}', ha='center', va='bottom', fontsize=11)
    plt.grid(True, linestyle='--', alpha=0.4, axis='y')
    plt.tight_layout()
    plt.savefig('osi_comparison_corrected.png', dpi=300)
    plt.show()

def top_markers_trend():
    if not core_markers:
        return
    top3 = sorted(core_markers, key=lambda cid: Phi[cid], reverse=True)[:3]
    name_map = {'XL': '香玲', 'LG': '鲁光', 'SH': '山核桃'}
    colors = {'XL': '#4C72B0', 'LG': '#55A868', 'SH': '#DD8452'}
    markers = {'XL': 'o', 'LG': 's', 'SH': '^'}
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for idx, cid in enumerate(top3):
        ax = axes[idx]
        for p in oil_types:
            times = time_points[p]
            series = data[p][cid] if cid in data[p] else [0] * len(times)
            ax.plot(times, series, marker=markers[p], markersize=5, linewidth=2,
                    label=name_map[p], color=colors[p],
                    markeredgecolor='white', markeredgewidth=0.8)
        # 简化化合物名称显示
        short_name = cid.replace('_', '-')  # 保留可读性
        ax.set_title(f'{short_name}\nΦ={Phi[cid]:.3f}', fontsize=11)
        ax.set_xlabel('氧化时间 (天)', fontsize=10)
        ax.set_ylabel('含量 (μg/kg)', fontsize=10)
        ax.legend(fontsize=9, framealpha=0.9, edgecolor='none')
        ax.grid(True, linestyle='--', alpha=0.4, axis='y')
    plt.tight_layout()
    plt.savefig('top_markers_trend_corrected.png', dpi=300)
    plt.show()

if core_markers:
    radar_chart()
else:
    print("\n警告：无核心标志物，跳过雷达图。")
bar_plot()
if core_markers:
    top_markers_trend()

# ==================== 12. 导出Excel结果文件 ====================
with pd.ExcelWriter('oxidation_analysis_results_corrected.xlsx') as writer:
    df_phi = pd.DataFrame({
        'compound_id': valid_compounds,
        'R_i': [R_i[cid] for cid in valid_compounds],
        'G_i': [G_i[cid] for cid in valid_compounds],
        'D_i': [D_i[cid] for cid in valid_compounds],
        'Phi': [Phi[cid] for cid in valid_compounds],
        'is_core': [cid in core_markers for cid in valid_compounds]
    })
    df_phi.to_excel(writer, sheet_name='化合物综合评分', index=False)
    
    rows = []
    for cid in core_markers:
        for p in oil_types:
            rows.append({
                'compound_id': cid,
                'oil_type': p,
                'U': U_dict[p][cid],
                'tau': tau_dict[p][cid],
                'Z': Z_dict[p][cid]
            })
    if rows:
        df_sub = pd.DataFrame(rows)
        df_sub.to_excel(writer, sheet_name='核心标志物子指标', index=False)
    
    df_osi = pd.DataFrame([{'oil_type': p, 'OSI': OSI[p]} for p in oil_types])
    df_osi.to_excel(writer, sheet_name='氧化稳定性评分', index=False)

print("\n修正后的结果已保存至 oxidation_analysis_results_corrected.xlsx")
print("可视化图片已保存: radar_chart_corrected.png, osi_comparison_corrected.png, top_markers_trend_corrected.png")