import pandas as pd
import numpy as np
import os

# ================== 读取数据 ==================
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')

# 日期列
day_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
df[day_cols] = df[day_cols].fillna(0)

# 定义每种油的结束时间和对应列
oil_end = {
    '香玲': {'end_col': 'day_7', 'days': 7},
    '鲁光': {'end_col': 'day_7', 'days': 7},
    '山核桃': {'end_col': 'day_10', 'days': 10}
}

# 微小量 epsilon
EPS = 1e-9

# ================== 1. 计算每个化合物的平均日增长量 ==================
results = []  # 存储每条记录 (oil_type, category, compound, v_avg, rel_rate)
for oil, info in oil_end.items():
    oil_df = df[df['oil_type'] == oil]
    for _, row in oil_df.iterrows():
        cat = row['category']
        comp = row['compound']
        X_start = row['day_0']
        X_end = row[info['end_col']]
        delta_t = info['days']
        v_avg = (X_end - X_start) / delta_t
        
        # 修正后的相对日均增长率（加入 epsilon）
        rel_rate = ((X_end / (X_start + EPS)) ** (1/delta_t) - 1) * 100
        
        results.append({
            'oil_type': oil,
            'category': cat,
            'compound': comp,
            'v_avg': v_avg,
            'rel_rate': rel_rate
        })
result_df = pd.DataFrame(results)

# ================== 2. 输出高增长和高衰减化合物 ==================
top_n = 5
for oil in oil_end.keys():
    oil_res = result_df[result_df['oil_type'] == oil].copy()
    oil_res = oil_res.sort_values('v_avg', ascending=False)
    
    print(f"\n{'='*70}")
    print(f"{oil} 的高增长化合物（按平均日增长量降序前{top_n}）：")
    print(f"{'='*70}")
    for idx, row in oil_res.head(top_n).iterrows():
        print(f"  {row['compound']} ({row['category']}) : 绝对速率 = {row['v_avg']:.2f} μg/kg/天, 相对增长率 = {row['rel_rate']:.2f}%")
    
    print(f"\n{'='*70}")
    print(f"{oil} 的高衰减化合物（按平均日增长量升序前{top_n}）：")
    print(f"{'='*70}")
    for idx, row in oil_res.tail(top_n).iloc[::-1].iterrows():
        print(f"  {row['compound']} ({row['category']}) : 绝对速率 = {row['v_avg']:.2f} μg/kg/天, 相对增长率 = {row['rel_rate']:.2f}%")

# ================== 3. 输出高末期含量化合物 ==================
print("\n" + "="*70)
print("高末期含量化合物（结束日浓度前5）")
print("="*70)
for oil, info in oil_end.items():
    end_col = info['end_col']
    oil_df = df[df['oil_type'] == oil].copy()
    top5 = oil_df.sort_values(by=end_col, ascending=False).head(5)
    print(f"\n{oil}（{end_col}）：")
    for _, row in top5.iterrows():
        print(f"  {row['compound']} ({row['category']}) : {row[end_col]:.2f} μg/kg")