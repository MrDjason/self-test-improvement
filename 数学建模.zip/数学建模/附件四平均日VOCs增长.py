import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# ================== 全局样式 ==================
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

# ================== 读取数据 ==================
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')

# 所有日期列
day_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
df[day_cols] = df[day_cols].fillna(0)

# 计算每种油每天的总VOCs
total_vocs = df.groupby('oil_type')[day_cols].sum().reset_index()

# 定义起止
oil_time = {
    '香玲': {'start': 'day_0', 'end': 'day_7', 't_start': 0, 't_end': 7},
    '鲁光': {'start': 'day_0', 'end': 'day_7', 't_start': 0, 't_end': 7},
    '山核桃': {'start': 'day_0', 'end': 'day_10', 't_start': 0, 't_end': 10}
}

# 计算绝对日均变化量
results = []
for _, row in total_vocs.iterrows():
    oil = row['oil_type']
    info = oil_time[oil]
    X_start = row[info['start']]
    X_end = row[info['end']]
    delta_t = info['t_end'] - info['t_start']
    abs_rate = (X_end - X_start) / delta_t
    results.append({'oil_type': oil, 'avg_daily_absolute_change': abs_rate})

df_abs = pd.DataFrame(results)
print("绝对日均变化量 (μg/kg/day):")
print(df_abs)

# ================== 绘制柱状图 ==================
plt.figure(figsize=(8, 5))
colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
x_pos = np.arange(len(results))
rates = [r['avg_daily_absolute_change'] for r in results]
oil_names = [r['oil_type'] for r in results]
bar_colors = [colors[oil] for oil in oil_names]

bars = plt.bar(x_pos, rates, color=bar_colors, edgecolor='white', linewidth=1.2, alpha=0.85)

# 添加数值标签
for bar, rate in zip(bars, rates):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
             f'{rate:.2f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

ylabel = '绝\n对\n日\n均\n变\n化\n量\n(μg/kg天)'
plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
plt.title('三种核桃油总VOCs的绝对日均变化量对比', fontsize=14, pad=12)
plt.xticks(x_pos, oil_names, fontsize=11)
plt.grid(axis='y', linestyle='--', alpha=0.4)
# 隐藏顶部和右侧边框
for spine in plt.gca().spines.values():
    spine.set_visible(False)
plt.tight_layout()
plt.savefig('绝对日均变化量柱状图.png', dpi=300, bbox_inches='tight')
plt.show()