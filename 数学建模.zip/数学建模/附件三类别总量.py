import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
import os
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据（请确保 csv 文件路径正确）
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')  # 避免BOM问题

# 定义时间点列
time_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
day_map = {'day_0':0, 'day_1':1, 'day_2':2, 'day_3':3, 'day_5':5, 'day_7':7, 'day_10':10}

oil_types = df['oil_type'].unique()
print(f"油品类型: {oil_types}")

for oil in oil_types:
    # 筛选当前油的数据
    oil_df = df[df['oil_type'] == oil].copy()
    
    # 有效时间列（至少有一行非空）
    valid_time_cols = []
    for col in time_cols:
        if col in oil_df.columns and not oil_df[col].isna().all():
            valid_time_cols.append(col)
    print(f"\n{oil} 有效时间列: {valid_time_cols}")
    
    # 填充缺失值为0
    for col in valid_time_cols:
        oil_df[col] = pd.to_numeric(oil_df[col], errors='coerce').fillna(0)
    
    # 按类别分组求和
    category_totals = oil_df.groupby('category')[valid_time_cols].sum()
    daily_totals = category_totals.T
    daily_totals.index = [day_map[col] for col in daily_totals.index]
    daily_totals = daily_totals.sort_index()
    
    print(f"\n{oil} 各类别每日总量汇总（单位：μg/kg）:")
    print(daily_totals.round(2))
    
    # ===== 绘图部分（方案二：分别绘制，大面积半透明底层，小面积不透明顶层）=====
    # 1. 按各类别总面积从大到小排序（大面积在前，小面积在后）
    total_per_category = daily_totals.sum(axis=0)
    sorted_cats = total_per_category.sort_values(ascending=False).index
    daily_totals_sorted = daily_totals[sorted_cats]
    
    # 2. 创建图形
    fig, ax = plt.subplots(figsize=(12, 4))
    colors = plt.cm.tab10(range(len(daily_totals_sorted.columns)))
    
    # 3. 分别绘制每个类别（先绘制大面积，后绘制小面积）
    for i, col in enumerate(daily_totals_sorted.columns):
        # 最后一个小面积类别完全不透明，其他大面积半透明
        if i == len(daily_totals_sorted.columns) - 1:
            alpha = 1.0      # 顶层（小面积）
        else:
            alpha = 0.3      # 底层（大面积）
        ax.fill_between(daily_totals_sorted.index,
                        0,
                        daily_totals_sorted[col].values,
                        alpha=alpha,
                        label=col,
                        color=colors[i])
    
    # 4. 设置标题、坐标轴、图例等
    ax.set_title(f'{oil}核桃油VOCs各类别总量随时间变化', fontsize=14)
    ax.set_xlabel('氧化时间 (天)', fontsize=12)
    ylabel = '各\n类\n别\n总\n含\n量\n(μg/kg)'
    ax.set_ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
    ax.legend(title='类别', bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(alpha=0.3, linestyle='--')
    ax.set_xticks(daily_totals_sorted.index)
    ax.set_xticklabels(daily_totals_sorted.index)
    
    plt.tight_layout()
    plt.subplots_adjust(top=0.94, bottom=0.11)
    plt.savefig(f'{oil}_VOCs_category_stackplot.png', dpi=300, bbox_inches='tight')
    plt.show()