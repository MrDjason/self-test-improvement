import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
import os
from docx import Document

warnings.filterwarnings('ignore')

# ================== 数据清洗模块（原附件一）==================
def extract_float(value_str):
    """从带后缀的字符串中提取数字，如 '42.55 ± 4.05 d' -> 42.55"""
    if not value_str or value_str.strip() in ('--', '—', '', 'nd'):
        return 0.0
    match = re.search(r'(\d+\.?\d*)', value_str)
    return float(match.group(1)) if match else 0.0

def is_header_row(row):
    """判断某行是否为表头行（包含 '0d' 或 '1d' 等天数）"""
    for cell in row:
        if re.match(r'\d+d', str(cell)):
            return True
    return False

def is_category_header(cell):
    """判断单元格是否为类别/种类等表头文字"""
    if not cell:
        return False
    return any(keyword in cell for keyword in ['类别', '种类', '化合物', '浓度'])

def parse_oil_data(rows, oil_name):
    """解析单个油品的所有行（已经切分好的从表头到下一个表头之间的行）"""
    header_idx = None
    for i, row in enumerate(rows):
        if is_header_row(row):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError(f"在 {oil_name} 的数据中未找到表头行")

    header_row = rows[header_idx]
    time_indices = []
    day_mapping = {}
    for idx, cell in enumerate(header_row):
        if re.match(r'\d+d', str(cell)):
            day_num = re.search(r'(\d+)', str(cell)).group(1)
            col_name = f'day_{day_num}'
            time_indices.append(idx)
            day_mapping[idx] = col_name

    data_rows = rows[header_idx+1:]
    records = []
    current_category = None

    for row in data_rows:
        if len(row) < 2:
            continue
        if len(row) > 1 and ('小计' in str(row[1]) or '总和' in str(row[1]) or '合计' in str(row[1])):
            continue
        if is_category_header(row[0]) and (len(row) > 1 and is_category_header(row[1])):
            continue

        if row[0] and row[0].strip() != '' and not is_category_header(row[0]):
            current_category = row[0].strip()

        compound = row[1] if len(row) > 1 else ''
        if not compound or compound == '' or compound == '化合物':
            continue

        conc = {}
        for idx in time_indices:
            if idx < len(row):
                val = extract_float(row[idx])
            else:
                val = 0.0
            conc[day_mapping[idx]] = val

        record = {
            'oil_type': oil_name,
            'category': current_category,
            'compound': compound,
            **conc
        }
        records.append(record)

    return pd.DataFrame(records)

def data_cleaning():
    """执行数据清洗，生成核桃油VOCs清洗后数据.csv，并返回DataFrame"""
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '附件.docx')
    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')

    doc = Document(file_path)
    all_rows = []
    for table in doc.tables:
        for row in table.rows:
            row_data = [cell.text.strip() for cell in row.cells]
            all_rows.append(row_data)

    header_indices = [i for i, row in enumerate(all_rows) if is_header_row(row)]
    print(f"找到 {len(header_indices)} 个表头行，位置：{header_indices}")

    oil_names = ['香玲', '鲁光', '山核桃']
    dfs = []

    for idx, start in enumerate(header_indices):
        end = header_indices[idx+1] if idx+1 < len(header_indices) else len(all_rows)
        oil_rows = all_rows[start:end]

        detected_name = None
        for row in oil_rows[:20]:
            row_str = ' '.join(str(cell) for cell in row)
            if '香玲' in row_str:
                detected_name = '香玲'
                break
            if '鲁光' in row_str:
                detected_name = '鲁光'
                break
            if '山核桃' in row_str:
                detected_name = '山核桃'
                break

        if detected_name is None and idx < len(oil_names):
            detected_name = oil_names[idx]
        elif detected_name is None:
            detected_name = f'未知{idx+1}'

        print(f"处理 {detected_name}，数据行范围 {start}~{end}")
        df = parse_oil_data(oil_rows, detected_name)
        dfs.append(df)

    final_df = pd.concat(dfs, ignore_index=True)
    first_cols = ['oil_type', 'category', 'compound']
    day_cols = [col for col in final_df.columns if col.startswith('day_')]
    day_cols_sorted = sorted(day_cols, key=lambda x: int(x.split('_')[1]))
    final_df = final_df[first_cols + day_cols_sorted]

    final_df.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"数据已保存至：{output_path}")
    print(f"总行数：{len(final_df)}")
    print("前10行预览：")
    print(final_df.head(10))
    return final_df

# ================== 附件二：总VOCs趋势图 ==================
def plot_total_vocs():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path)

    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
    plt.rcParams['axes.spines.top'] = False
    plt.rcParams['axes.spines.right'] = False

    all_time_cols = [col for col in df.columns if col.startswith('day_')]
    oil_types = df['oil_type'].unique()
    result = {}

    for oil in oil_types:
        oil_df = df[df['oil_type'] == oil]
        valid_cols = []
        for col in all_time_cols:
            if col in oil_df.columns and not oil_df[col].isna().all():
                valid_cols.append(col)
        if not valid_cols:
            continue
        days = [int(col.split('_')[1]) for col in valid_cols]
        time_data = oil_df[valid_cols].fillna(0).values
        total_per_day = time_data.sum(axis=0)
        result[oil] = (days, total_per_day)

    plt.figure(figsize=(10, 6))
    colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
    markers = {'香玲': 'o', '鲁光': 's', '山核桃': '^'}

    for oil, (days, totals) in result.items():
        plt.plot(days, totals,
                 marker=markers[oil],
                 color=colors[oil],
                 linewidth=2.5,
                 markersize=6,
                 markeredgecolor='white',
                 markeredgewidth=0.8,
                 alpha=0.9,
                 label=oil)

        for d, t in zip(days, totals):
            offset = 20 if t >= 0 else -8
            plt.text(d, t + offset, f'{t:.1f}',
                     ha='center', va='bottom' if offset > 0 else 'top',
                     fontsize=8, color=colors[oil], alpha=0.8)

    plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
    y_label = "总\n挥\n发\n性\n有\n机\n物\n浓\n度\n(μg/kg)"
    plt.ylabel(y_label, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
    plt.title('三种核桃油总VOCs随氧化时间的变化趋势', fontsize=14, pad=12)
    plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='best')
    plt.grid(True, linestyle='--', alpha=0.4, axis='y')

    all_days = sorted(set().union(*[d for d, _ in result.values()]))
    plt.xticks(all_days, fontsize=10)
    plt.yticks(fontsize=10)

    plt.tight_layout()
    plt.savefig('总VOCs趋势图.png', dpi=300, bbox_inches='tight')
    plt.show()

    print("各油品总VOCs（单位：μg/kg）：")
    for oil, (days, totals) in result.items():
        print(f"\n{oil}:")
        for d, t in zip(days, totals):
            print(f"  day_{d}: {t:.2f}")

# ================== 附件三：类别总量堆叠面积图 ==================
def plot_category_stack():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path, encoding='utf-8-sig')
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False

    time_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
    day_map = {'day_0':0, 'day_1':1, 'day_2':2, 'day_3':3, 'day_5':5, 'day_7':7, 'day_10':10}
    oil_types = df['oil_type'].unique()

    for oil in oil_types:
        oil_df = df[df['oil_type'] == oil].copy()
        valid_time_cols = []
        for col in time_cols:
            if col in oil_df.columns and not oil_df[col].isna().all():
                valid_time_cols.append(col)
        for col in valid_time_cols:
            oil_df[col] = pd.to_numeric(oil_df[col], errors='coerce').fillna(0)

        category_totals = oil_df.groupby('category')[valid_time_cols].sum()
        daily_totals = category_totals.T
        daily_totals.index = [day_map[col] for col in daily_totals.index]
        daily_totals = daily_totals.sort_index()

        print(f"\n{oil} 各类别每日总量汇总（单位：μg/kg）:")
        print(daily_totals.round(2))

        total_per_category = daily_totals.sum(axis=0)
        sorted_cats = total_per_category.sort_values(ascending=False).index
        daily_totals_sorted = daily_totals[sorted_cats]

        fig, ax = plt.subplots(figsize=(12, 4))
        colors = plt.cm.tab10(range(len(daily_totals_sorted.columns)))

        for i, col in enumerate(daily_totals_sorted.columns):
            alpha = 1.0 if i == len(daily_totals_sorted.columns) - 1 else 0.3
            ax.fill_between(daily_totals_sorted.index,
                            0,
                            daily_totals_sorted[col].values,
                            alpha=alpha,
                            label=col,
                            color=colors[i])

        ax.set_title(f'{oil}核桃油VOCs各类别总量随时间变化', fontsize=14)
        ax.set_xlabel('氧化时间 (天)', fontsize=12)
        ylabel = '各\n类\n别\n总\n含\n量\n(μg/kg)'
        ax.set_ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
        ax.legend(title='类别', bbox_to_anchor=(1.05, 1), loc='upper left')
        ax.grid(alpha=0.3, linestyle='--')
        ax.set_xticks(daily_totals_sorted.index)
        ax.set_xticklabels(daily_totals_sorted.index)

        plt.tight_layout()
        plt.subplots_adjust(top=0.94, bottom=0.11)
        plt.savefig(f'{oil}_VOCs_category_stackplot.png', dpi=300, bbox_inches='tight')
        plt.show()

# ================== 附件四：各化合物日均增长率（打印高增长/高衰减）==================
def print_compound_growth_rates():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path, encoding='utf-8-sig')
    all_day_cols = [col for col in df.columns if col.startswith('day_')]

    oil_period = {
        '香玲': {'start': 0, 'end': 7},
        '鲁光': {'start': 0, 'end': 7},
        '山核桃': {'start': 0, 'end': 10}
    }

    categories = df['category'].unique()
    oil_category_growth = {}

    for oil in df['oil_type'].unique():
        oil_df = df[df['oil_type'] == oil]
        valid_cols = []
        for col in all_day_cols:
            if oil_df[col].notna().any():
                valid_cols.append(col)
        if not valid_cols:
            continue
        valid_cols_sorted = sorted(valid_cols, key=lambda x: int(x.split('_')[1]))
        days = [int(col.split('_')[1]) for col in valid_cols_sorted]

        category_daily = {}
        for cat in categories:
            cat_df = oil_df[oil_df['category'] == cat]
            if cat_df.empty:
                continue
            daily_totals = []
            for col in valid_cols_sorted:
                daily_totals.append(cat_df[col].fillna(0).sum())
            category_daily[cat] = np.array(daily_totals)

        category_growth = {}
        for cat, totals in category_daily.items():
            x_vals = []
            y_vals = []
            for i in range(1, len(days)):
                t_prev = days[i-1]
                t_cur = days[i]
                V_prev = totals[i-1]
                V_cur = totals[i]
                delta_days = t_cur - t_prev
                if V_prev > 0:
                    daily_rate = ((V_cur / V_prev) ** (1/delta_days) - 1) * 100
                else:
                    daily_rate = np.nan
                x_vals.append(t_cur)
                y_vals.append(daily_rate)
            x_vals.insert(0, 0)
            y_vals.insert(0, 0.0)
            category_growth[cat] = (x_vals, y_vals)
        oil_category_growth[oil] = category_growth

    # 绘制各类别日增长率图（每个油品一张）
    cat_colors = {
        '醇': '#4C72B0', '醛': '#55A868', '酯': '#DD8452',
        '酸': '#9467BD', '酮': '#8C564B', '其他': '#E377C2'
    }
    cat_markers = {
        '醇': 'o', '醛': 's', '酯': '^',
        '酸': 'D', '酮': 'v', '其他': 'p'
    }

    for oil, cat_growth in oil_category_growth.items():
        plt.figure(figsize=(8, 5))
        for cat, (x_vals, y_vals) in cat_growth.items():
            mask = ~np.isnan(y_vals)
            x_clean = np.array(x_vals)[mask]
            y_clean = np.array(y_vals)[mask]
            if len(x_clean) == 0:
                continue
            plt.plot(x_clean, y_clean,
                     marker=cat_markers.get(cat, 'o'),
                     color=cat_colors.get(cat, '#000000'),
                     linewidth=2.5,
                     markersize=6,
                     markeredgecolor='white',
                     markeredgewidth=0.8,
                     alpha=0.9,
                     label=cat)
            for x, y in zip(x_clean, y_clean):
                if x == 0 and y == 0.0:
                    continue
                offset = 1 if y >= 0 else -1.5
                plt.text(x, y + offset, f'{y:.1f}%',
                         ha='center', va='bottom' if y >= 0 else 'top',
                         fontsize=8, color=cat_colors.get(cat, '#000000'), alpha=0.8)

        plt.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.6)
        plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
        ylabel = '日\n增\n长\n率\n(%)'
        plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
        plt.title(f'{oil}各类别VOCs总量的日增长率变化', fontsize=14, pad=12)
        plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='center left', bbox_to_anchor=(1, 0.5))
        plt.grid(True, linestyle='--', alpha=0.4, axis='y')

        oil_df = df[df['oil_type'] == oil]
        valid_cols = [col for col in all_day_cols if oil_df[col].notna().any()]
        all_days = sorted([int(col.split('_')[1]) for col in valid_cols])
        xticks = [0] + all_days
        plt.xticks(xticks, fontsize=10)
        plt.yticks(fontsize=10)
        plt.xlim(left=0)

        plt.tight_layout()
        plt.savefig(f'{oil}_各类别日增长率趋势图.png', dpi=300, bbox_inches='tight')
        plt.show()
        print(f"已保存：{oil}_各类别日增长率趋势图.png")

# ================== 附件四（平均VOCs日均增长率）：整体增长率和相邻日增长率图 ==================
def plot_total_vocs_daily_growth_rate():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path, encoding='utf-8-sig')

    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
    plt.rcParams['axes.spines.top'] = False
    plt.rcParams['axes.spines.right'] = False

    all_day_cols = [col for col in df.columns if col.startswith('day_')]
    oil_period = {
        '香玲': {'start': 0, 'end': 7},
        '鲁光': {'start': 0, 'end': 7},
        '山核桃': {'start': 0, 'end': 10}
    }

    plot_data = {}
    growth_rates = []

    for oil in df['oil_type'].unique():
        oil_df = df[df['oil_type'] == oil]
        valid_cols = []
        for col in all_day_cols:
            if oil_df[col].notna().any():
                valid_cols.append(col)
        if not valid_cols:
            continue
        valid_cols_sorted = sorted(valid_cols, key=lambda x: int(x.split('_')[1]))
        days = [int(col.split('_')[1]) for col in valid_cols_sorted]
        totals = [oil_df[col].fillna(0).sum() for col in valid_cols_sorted]
        plot_data[oil] = (days, totals)

        start_day = oil_period[oil]['start']
        end_day = oil_period[oil]['end']
        start_idx = days.index(start_day) if start_day in days else None
        end_idx = days.index(end_day) if end_day in days else None
        if start_idx is not None and end_idx is not None:
            X_start = totals[start_idx]
            X_end = totals[end_idx]
            delta_t = end_day - start_day
            abs_rate = (X_end - X_start) / delta_t
            rel_rate = ((X_end / X_start) ** (1/delta_t) - 1) * 100 if X_start > 0 else np.nan
            growth_rates.append({
                'oil_type': oil,
                'absolute_daily_change (μg/kg/day)': abs_rate,
                'relative_total_growth_rate (%/day)': rel_rate
            })

    print("="*60)
    print("整体日均增长率（从起始到结束）")
    print("="*60)
    growth_df = pd.DataFrame(growth_rates)
    print(growth_df.to_string(index=False))

    # 相邻日增长率
    segment_growth = {}
    for oil, (days, totals) in plot_data.items():
        x_seg, rates = [], []
        for i in range(1, len(days)):
            t_prev, t_cur = days[i-1], days[i]
            V_prev, V_cur = totals[i-1], totals[i]
            delta_days = t_cur - t_prev
            daily_rate = ((V_cur / V_prev) ** (1/delta_days) - 1) * 100 if V_prev > 0 else np.nan
            x_seg.append(t_cur)
            rates.append(daily_rate)
        segment_growth[oil] = (x_seg, rates)

    plt.figure(figsize=(10, 6))
    colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
    markers = {'香玲': 'o', '鲁光': 's', '山核桃': '^'}

    for oil, (x_vals, y_vals) in segment_growth.items():
        mask = ~np.isnan(y_vals)
        x_clean, y_clean = np.array(x_vals)[mask], np.array(y_vals)[mask]
        if len(x_clean) == 0:
            continue
        plt.plot(x_clean, y_clean,
                 marker=markers[oil],
                 color=colors[oil],
                 linewidth=2.5,
                 markersize=6,
                 markeredgecolor='white',
                 markeredgewidth=0.8,
                 alpha=0.9,
                 label=oil)
        for x, y in zip(x_clean, y_clean):
            offset = 1 if y >= 0 else -1.5
            plt.text(x, y + offset, f'{y:.1f}%',
                     ha='center', va='bottom' if y >= 0 else 'top',
                     fontsize=8, color=colors[oil], alpha=0.8)

    plt.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.6)
    plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
    ylabel = '日\n增\n长\n率\n(%)'
    plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
    plt.title('三种核桃油总VOCs日增长率变化', fontsize=14, pad=12)
    plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='best')
    plt.grid(True, linestyle='--', alpha=0.4, axis='y')

    all_days = sorted(set().union(*[d for d, _ in plot_data.values()]))
    plt.xticks(all_days, fontsize=10)
    plt.yticks(fontsize=10)
    plt.tight_layout()
    plt.savefig('总VOCs相邻日增长率趋势图.png', dpi=300, bbox_inches='tight')
    plt.show()

# ================== 附件四（平均日VOCs增长）：绝对日均变化量柱状图 ==================
def plot_avg_daily_absolute_change():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path, encoding='utf-8-sig')

    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
    plt.rcParams['axes.spines.top'] = False
    plt.rcParams['axes.spines.right'] = False

    day_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
    df[day_cols] = df[day_cols].fillna(0)
    total_vocs = df.groupby('oil_type')[day_cols].sum().reset_index()

    oil_time = {
        '香玲': {'start': 'day_0', 'end': 'day_7', 't_start': 0, 't_end': 7},
        '鲁光': {'start': 'day_0', 'end': 'day_7', 't_start': 0, 't_end': 7},
        '山核桃': {'start': 'day_0', 'end': 'day_10', 't_start': 0, 't_end': 10}
    }

    results = []
    for _, row in total_vocs.iterrows():
        oil = row['oil_type']
        info = oil_time[oil]
        X_start, X_end = row[info['start']], row[info['end']]
        delta_t = info['t_end'] - info['t_start']
        abs_rate = (X_end - X_start) / delta_t
        results.append({'oil_type': oil, 'avg_daily_absolute_change': abs_rate})

    df_abs = pd.DataFrame(results)
    print("绝对日均变化量 (μg/kg/day):")
    print(df_abs)

    plt.figure(figsize=(8, 5))
    colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
    x_pos = np.arange(len(results))
    rates = [r['avg_daily_absolute_change'] for r in results]
    oil_names = [r['oil_type'] for r in results]
    bar_colors = [colors[oil] for oil in oil_names]

    bars = plt.bar(x_pos, rates, color=bar_colors, edgecolor='white', linewidth=1.2, alpha=0.85)

    for bar, rate in zip(bars, rates):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                 f'{rate:.2f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

    ylabel = '绝\n对\n日\n均\n变\n化\n量\n(μg/kg天)'
    plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
    plt.title('三种核桃油总VOCs的绝对日均变化量对比', fontsize=14, pad=12)
    plt.xticks(x_pos, oil_names, fontsize=11)
    plt.grid(axis='y', linestyle='--', alpha=0.4)
    for spine in plt.gca().spines.values():
        spine.set_visible(False)
    plt.tight_layout()
    plt.savefig('绝对日均变化量柱状图.png', dpi=300, bbox_inches='tight')
    plt.show()

# ================== 附件五：高增长、高衰减、高末期化合物 ==================
def print_high_growth_decay_end():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
    df = pd.read_csv(file_path, encoding='utf-8-sig')
    day_cols = ['day_0', 'day_1', 'day_2', 'day_3', 'day_5', 'day_7', 'day_10']
    df[day_cols] = df[day_cols].fillna(0)

    oil_end = {
        '香玲': {'end_col': 'day_7', 'days': 7},
        '鲁光': {'end_col': 'day_7', 'days': 7},
        '山核桃': {'end_col': 'day_10', 'days': 10}
    }

    EPS = 1e-9
    results = []
    for oil, info in oil_end.items():
        oil_df = df[df['oil_type'] == oil]
        for _, row in oil_df.iterrows():
            cat = row['category']
            comp = row['compound']
            X_start = row['day_0']
            X_end = row[info['end_col']]
            delta_t = info['days']
            v_avg = (X_end - X_start) / delta_t
            rel_rate = ((X_end / (X_start + EPS)) ** (1/delta_t) - 1) * 100
            results.append({
                'oil_type': oil,
                'category': cat,
                'compound': comp,
                'v_avg': v_avg,
                'rel_rate': rel_rate
            })
    result_df = pd.DataFrame(results)

    top_n = 5
    for oil in oil_end.keys():
        oil_res = result_df[result_df['oil_type'] == oil].copy()
        oil_res = oil_res.sort_values('v_avg', ascending=False)

        print(f"\n{'='*70}")
        print(f"{oil} 的高增长化合物（按平均日增长量降序前{top_n}）：")
        print(f"{'='*70}")
        for idx, row in oil_res.head(top_n).iterrows():
            print(f"  {row['compound']} ({row['category']}) : 绝对速率 = {row['v_avg']:.2f} μg/kg/天, 相对增长率 = {row['rel_rate']:.2f}%")

        print(f"\n{'='*70}")
        print(f"{oil} 的高衰减化合物（按平均日增长量升序前{top_n}）：")
        print(f"{'='*70}")
        for idx, row in oil_res.tail(top_n).iloc[::-1].iterrows():
            print(f"  {row['compound']} ({row['category']}) : 绝对速率 = {row['v_avg']:.2f} μg/kg/天, 相对增长率 = {row['rel_rate']:.2f}%")

    print("\n" + "="*70)
    print("高末期含量化合物（结束日浓度前5）")
    print("="*70)
    for oil, info in oil_end.items():
        end_col = info['end_col']
        oil_df = df[df['oil_type'] == oil].copy()
        top5 = oil_df.sort_values(by=end_col, ascending=False).head(5)
        print(f"\n{oil}（{end_col}）：")
        for _, row in top5.iterrows():
            print(f"  {row['compound']} ({row['category']}) : {row[end_col]:.2f} μg/kg")

# ================== 主程序 ==================
def main():
    print("===== 步骤1：数据清洗 =====")
    data_cleaning()

    print("\n===== 步骤2：总VOCs趋势图 =====")
    plot_total_vocs()

    print("\n===== 步骤3：各类别总量堆叠图 =====")
    plot_category_stack()

    print("\n===== 步骤4：各化合物日均增长率及各类别日增长率图 =====")
    print_compound_growth_rates()

    print("\n===== 步骤5：整体增长率及总VOCs相邻日增长率图 =====")
    plot_total_vocs_daily_growth_rate()

    print("\n===== 步骤6：绝对日均变化量柱状图 =====")
    plot_avg_daily_absolute_change()

    print("\n===== 步骤7：高增长/高衰减/高末期化合物 =====")
    print_high_growth_decay_end()

    print("\n所有任务执行完毕！")

if __name__ == '__main__':
    main()