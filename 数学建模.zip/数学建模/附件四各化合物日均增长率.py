import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# ================== 全局样式 ==================
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

# ================== 读取数据 ==================
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')

all_day_cols = [col for col in df.columns if col.startswith('day_')]

oil_period = {
    '香玲': {'start': 0, 'end': 7},
    '鲁光': {'start': 0, 'end': 7},
    '山核桃': {'start': 0, 'end': 10}
}

categories = df['category'].unique()
oil_category_growth = {}

for oil in df['oil_type'].unique():
    oil_df = df[df['oil_type'] == oil]
    
    valid_cols = []
    for col in all_day_cols:
        if oil_df[col].notna().any():
            valid_cols.append(col)
    if not valid_cols:
        continue
    valid_cols_sorted = sorted(valid_cols, key=lambda x: int(x.split('_')[1]))
    days = [int(col.split('_')[1]) for col in valid_cols_sorted]
    
    category_daily = {}
    for cat in categories:
        cat_df = oil_df[oil_df['category'] == cat]
        if cat_df.empty:
            continue
        daily_totals = []
        for col in valid_cols_sorted:
            daily_totals.append(cat_df[col].fillna(0).sum())
        category_daily[cat] = np.array(daily_totals)
    
    # ========== 修改部分：计算增长率并插入原点 ==========
    category_growth = {}
    for cat, totals in category_daily.items():
        x_vals = []
        y_vals = []
        for i in range(1, len(days)):
            t_prev = days[i-1]
            t_cur = days[i]
            V_prev = totals[i-1]
            V_cur = totals[i]
            delta_days = t_cur - t_prev
            if V_prev > 0:
                daily_rate = ((V_cur / V_prev) ** (1/delta_days) - 1) * 100
            else:
                daily_rate = np.nan
            x_vals.append(t_cur)
            y_vals.append(daily_rate)
        # 在开头插入 (0, 0)
        x_vals.insert(0, 0)
        y_vals.insert(0, 0.0)
        category_growth[cat] = (x_vals, y_vals)
    # ==============================================
    oil_category_growth[oil] = category_growth

# ================== 绘图（保持不变，但x轴刻度需包含0） ==================
cat_colors = {
    '醇': '#4C72B0',
    '醛': '#55A868',
    '酯': '#DD8452',
    '酸': '#9467BD',
    '酮': '#8C564B',
    '其他': '#E377C2'
}
cat_markers = {
    '醇': 'o',
    '醛': 's',
    '酯': '^',
    '酸': 'D',
    '酮': 'v',
    '其他': 'p'
}

for oil, cat_growth in oil_category_growth.items():
    plt.figure(figsize=(8, 5))
    
    for cat, (x_vals, y_vals) in cat_growth.items():
        mask = ~np.isnan(y_vals)
        x_clean = np.array(x_vals)[mask]
        y_clean = np.array(y_vals)[mask]
        if len(x_clean) == 0:
            continue
        plt.plot(x_clean, y_clean,
                 marker=cat_markers.get(cat, 'o'),
                 color=cat_colors.get(cat, '#000000'),
                 linewidth=2.5,
                 markersize=6,
                 markeredgecolor='white',
                 markeredgewidth=0.8,
                 alpha=0.9,
                 label=cat)
        # 数值标签：跳过原点 (0,0) 避免拥挤
        for x, y in zip(x_clean, y_clean):
            if x == 0 and y == 0.0:
                continue
            offset = 1 if y >= 0 else -1.5
            plt.text(x, y + offset, f'{y:.1f}%',
                     ha='center', va='bottom' if y >= 0 else 'top',
                     fontsize=8, color=cat_colors.get(cat, '#000000'), alpha=0.8)
    
    plt.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.6)
    plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
    ylabel = '日\n增\n长\n率\n(%)'
    plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
    plt.title(f'{oil}各类别VOCs总量的日增长率变化', fontsize=14, pad=12)
    plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='center left', bbox_to_anchor=(1, 0.5))
    plt.grid(True, linestyle='--', alpha=0.4, axis='y')
    
    # 获取所有测量天数（包含0）
    oil_df = df[df['oil_type'] == oil]
    valid_cols = [col for col in all_day_cols if oil_df[col].notna().any()]
    all_days = sorted([int(col.split('_')[1]) for col in valid_cols])
    # 确保 x 轴包含0
    xticks = [0] + all_days
    plt.xticks(xticks, fontsize=10)
    plt.yticks(fontsize=10)
    # 可选：设置 x 轴范围从0开始
    plt.xlim(left=0)
    
    plt.tight_layout()
    plt.savefig(f'{oil}_各类别日增长率趋势图.png', dpi=300, bbox_inches='tight')
    plt.show()
    print(f"已保存：{oil}_各类别日增长率趋势图.png")