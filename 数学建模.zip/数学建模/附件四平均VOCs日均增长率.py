import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# ================== 全局样式 ==================
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

# ================== 读取数据 ==================
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path, encoding='utf-8-sig')

# 所有可能的日期列
all_day_cols = [col for col in df.columns if col.startswith('day_')]

# 定义每种油的起止时间（用于计算总增长率）
oil_period = {
    '香玲': {'start': 0, 'end': 7},
    '鲁光': {'start': 0, 'end': 7},
    '山核桃': {'start': 0, 'end': 10}
}

# ================== 计算每种油的有效日期和总VOCs ==================
plot_data = {}          # 存储 (days, totals) 用于绘图
growth_rates = []       # 存储整体增长率

for oil in df['oil_type'].unique():
    oil_df = df[df['oil_type'] == oil]
    
    # 找出该油品有数据的日期列（至少有一个非NaN值）
    valid_cols = []
    for col in all_day_cols:
        if oil_df[col].notna().any():
            valid_cols.append(col)
    
    if not valid_cols:
        continue
    
    # 按天数排序
    valid_cols_sorted = sorted(valid_cols, key=lambda x: int(x.split('_')[1]))
    days = [int(col.split('_')[1]) for col in valid_cols_sorted]
    # 计算每个有效日期的总VOCs（缺失的化合物浓度视为0）
    totals = []
    for col in valid_cols_sorted:
        totals.append(oil_df[col].fillna(0).sum())
    
    plot_data[oil] = (days, totals)
    
    # 计算整体增长率（从 start 到 end）
    start_day = oil_period[oil]['start']
    end_day = oil_period[oil]['end']
    start_idx = days.index(start_day) if start_day in days else None
    end_idx = days.index(end_day) if end_day in days else None
    
    if start_idx is not None and end_idx is not None:
        X_start = totals[start_idx]
        X_end = totals[end_idx]
        delta_t = end_day - start_day
        abs_rate = (X_end - X_start) / delta_t
        if X_start > 0:
            rel_rate = ( (X_end / X_start) ** (1/delta_t) - 1 ) * 100
        else:
            rel_rate = np.nan
        growth_rates.append({
            'oil_type': oil,
            'absolute_daily_change (μg/kg/day)': abs_rate,
            'relative_total_growth_rate (%/day)': rel_rate
        })

# ================== 输出整体增长率计算结果 ==================
print("="*60)
print("整体日均增长率（从起始到结束）")
print("="*60)
growth_df = pd.DataFrame(growth_rates)
print(growth_df.to_string(index=False))

# ================== 计算相邻时间段的复合日增长率 ==================
# 存储每个油品的相邻日增长率数据
segment_growth = {}  # oil -> (x_days, growth_rates_per_day)

for oil, (days, totals) in plot_data.items():
    x_seg = []      # 每个时间段的结束时间点（或中间点，这里选结束点）
    rates = []      # 该时间段的复合日增长率（%）
    for i in range(1, len(days)):
        t_prev = days[i-1]
        t_cur = days[i]
        V_prev = totals[i-1]
        V_cur = totals[i]
        delta_days = t_cur - t_prev
        if V_prev > 0:
            # 复合日增长率 = ( (V_cur/V_prev)^(1/delta_days) - 1 ) * 100
            daily_rate = ( (V_cur / V_prev) ** (1/delta_days) - 1 ) * 100
        else:
            daily_rate = np.nan
        x_seg.append(t_cur)   # 将增长率画在结束时间点
        rates.append(daily_rate)
    segment_growth[oil] = (x_seg, rates)

# ================== 绘制相邻日增长率折线图 ==================
plt.figure(figsize=(10, 6))

colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
markers = {'香玲': 'o', '鲁光': 's', '山核桃': '^'}

for oil, (x_vals, y_vals) in segment_growth.items():
    # 过滤掉 nan 值（如果有）
    mask = ~np.isnan(y_vals)
    x_clean = np.array(x_vals)[mask]
    y_clean = np.array(y_vals)[mask]
    if len(x_clean) == 0:
        continue
    plt.plot(x_clean, y_clean,
             marker=markers[oil],
             color=colors[oil],
             linewidth=2.5,
             markersize=6,
             markeredgecolor='white',
             markeredgewidth=0.8,
             alpha=0.9,
             label=oil)
    # 添加数值标签
    for x, y in zip(x_clean, y_clean):
        offset = 1 if y >= 0 else -1.5   # 正负偏移不同
        plt.text(x, y + offset, f'{y:.1f}%',
                 ha='center', va='bottom' if y >= 0 else 'top',
                 fontsize=8, color=colors[oil], alpha=0.8)

# 添加零参考线
plt.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.6)

plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
ylabel = '日\n增\n长\n率\n(%)'
plt.ylabel(ylabel, fontsize=12, labelpad=25, rotation=0, va='center', ha='center')
plt.title('三种核桃油总VOCs日增长率变化', fontsize=14, pad=12)
plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='best')
plt.grid(True, linestyle='--', alpha=0.4, axis='y')
# 设置横轴刻度为所有出现过的天数
all_days = sorted(set().union(*[d for d, _ in plot_data.values()]))
plt.xticks(all_days, fontsize=10)
plt.yticks(fontsize=10)

plt.tight_layout()
plt.savefig('总VOCs相邻日增长率趋势图.png', dpi=300, bbox_inches='tight')
plt.show()