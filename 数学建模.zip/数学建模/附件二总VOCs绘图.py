import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# 设置全局样式
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

# 读取数据
file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '核桃油VOCs清洗后数据.csv')
df = pd.read_csv(file_path)

all_time_cols = [col for col in df.columns if col.startswith('day_')]

oil_types = df['oil_type'].unique()
result = {}

for oil in oil_types:
    oil_df = df[df['oil_type'] == oil]
    valid_cols = []
    for col in all_time_cols:
        if col in oil_df.columns and not oil_df[col].isna().all():
            valid_cols.append(col)
    if not valid_cols:
        continue
    days = [int(col.split('_')[1]) for col in valid_cols]
    time_data = oil_df[valid_cols].fillna(0).values
    total_per_day = time_data.sum(axis=0)
    result[oil] = (days, total_per_day)

# 绘图
plt.figure(figsize=(10, 6))

colors = {'香玲': '#4C72B0', '鲁光': '#55A868', '山核桃': '#DD8452'}
markers = {'香玲': 'o', '鲁光': 's', '山核桃': '^'}

for oil, (days, totals) in result.items():
    plt.plot(days, totals,
             marker=markers[oil],
             color=colors[oil],
             linewidth=2.5,
             markersize=6,
             markeredgecolor='white',
             markeredgewidth=0.8,
             alpha=0.9,
             label=oil)
    
    # 为每个数据点添加数值标签
    for d, t in zip(days, totals):
        # 偏移量：根据数值大小动态调整垂直偏移，避免与点重叠
        offset = 20 if t >= 0 else -8   # 正值在上方，负值在下方（一般浓度为正）
        plt.text(d, t + offset, f'{t:.1f}',
                 ha='center', va='bottom' if offset > 0 else 'top',
                 fontsize=8, color=colors[oil], alpha=0.8)

plt.xlabel('氧化时间 (天)', fontsize=12, labelpad=8)
y_label = "总\n挥\n发\n性\n有\n机\n物\n浓\n度\n(μg/kg)"
plt.ylabel(y_label, 
           fontsize=12, 
           labelpad=25,    # 向左移动
           rotation=0,     # 保持竖排
           va='center',    # 垂直居中
           ha='center')    # 水平居中
plt.title('三种核桃油总VOCs随氧化时间的变化趋势', fontsize=14, pad=12)
plt.legend(fontsize=11, framealpha=0.9, edgecolor='none', loc='best')
plt.grid(True, linestyle='--', alpha=0.4, axis='y')

all_days = sorted(set().union(*[d for d, _ in result.values()]))
plt.xticks(all_days, fontsize=10)
plt.yticks(fontsize=10)

plt.tight_layout()
plt.savefig('总VOCs趋势图.png', dpi=300, bbox_inches='tight')
plt.show()

print("各油品总VOCs（单位：μg/kg）：")
for oil, (days, totals) in result.items():
    print(f"\n{oil}:")
    for d, t in zip(days, totals):
        print(f"  day_{d}: {t:.2f}")