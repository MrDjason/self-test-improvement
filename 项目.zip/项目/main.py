import pandas as pd
import os
import time

column_mapping = {
    '10FGDAI001.UNIT4@NET0': 'jzfh',
    '10HTA10CF101A.UNIT4@NET0': 'yyq_LL',
    '10HTQ10CQ101.UNIT4@NET0': 'xstjy_PH',
    '10HTD10CD102.UNIT4@NET0': 'xstjy_MD',
    '10HTD10CL101.UNIT4@NET0': 'xst_YW',
    '10HTF11AP001I.UNIT4@NET0': 'xstjyxhb_ADL',
    '10HTF12AP001I.UNIT4@NET0': 'xstjyxhb_BDL',
    '10HTL90CF101.UNIT4@NET0': 'xstshsjy_LL',
    # '10HTD30CQ101.UNIT4@NET0': 'twjyxsg_PH1',
    # '10HTD30CL10HU.UNIT4@NET0': 'twjyx_YW',
    # '10HTF13AP001I.UNIT4@NET0': 'twjcxhb_ADL',
    # '10HTF14AP001I.UNIT4@NET0': 'twjcxhb_BDL',
    '10HTD20CQ101P.UNIT4@NET0': 'aptjy_PH',
    '10HTD20CD101.UNIT4@NET0': 'aptshsjy_MD',
    '10HTD20CL101P.UNIT4@NET0': 'apt_YW',
    '10HTF23AP001I.UNIT4@NET0': 'aptjyxhb_CDL',
    '10HTF22AP001I.UNIT4@NET0': 'aptjyxhb_BDL',
    '10HTF21AP001I.UNIT4@NET0': 'aptjyxhb_ADL',
    '10HTL90CF102.UNIT4@NET0': 'aptshsjy_LL',
    '10HTA10CQ101-ZS.UNIT4@NET0': 'yyq_SO2',
    '10HTA20CQ101-ZS.UNIT4@NET0': 'jyq_SO2',

    '20FGDAI001.UNIT4@NET0': 'jzfh',
    '20HTA10CQ101-RKZS.UNIT4@NET0': 'yyq_SO2',
    '20HTA10CF101.UNIT4@NET0': 'yyq_LL',
    '20HTQ10CQ101.UNIT4@NET0': 'xstjy_PH',
    '20HTD12CD102.UNIT4@NET0': 'xstjy_MD2',
    '20HTD10CL101.UNIT4@NET0': 'xst_YW',
    '20HTF11AP001I.UNIT4@NET0': 'xstjyxhb_ADL',
    '20HTF12AP001I.UNIT4@NET0': 'xstjyxhb_BDL',
    '20HTL90CF101.UNIT4@NET0': 'xstshsjy_LL',
    # '20HTD30CQ101.UNIT4@NET0': 'twjyxsg_PH1',
    # '20HTD30CL10HU.UNIT4@NET0': 'twjyx_YW',
    # '20HTF13AP001I.UNIT4@NET0': 'twjcxhb_ADL',
    # '20HTF14AP001I.UNIT4@NET0': 'twjcxhb_BDL',
    '20HTA20CQ101.UNIT4@NET0': 'jyq_SO2',
    '20HTD20CQ101P.UNIT4@NET0': 'aptjy_PH',
    '20HTD20CD101.UNIT4@NET0': 'aptshsjy_MD',
    '20HTD20CL101.UNIT4@NET0': 'apt_YW',
    '20HTF23AP001I.UNIT4@NET0': 'aptjyxhb_CDL',
    '20HTF22AP001I.UNIT4@NET0': 'aptjyxhb_BDL',
    '20HTF21AP001I.UNIT4@NET0': 'aptjyxhb_ADL',
    '20HTL90CF102.UNIT4@NET0': 'aptshsjy_LL',
}

ignore_columns = [
                # 塔1 需删除列
                '10HTD30CQ101.UNIT4@NET0',
                '10HTD30CL10HU.UNIT4@NET0',
                '10HTF13AP001I.UNIT4@NET0',
                '10HTF14AP001I.UNIT4@NET0',
                # 塔2 需删除列
                '20HTD30CQ101.UNIT4@NET0',
                '20HTD30CL10HU.UNIT4@NET0',
                '20HTF13AP001I.UNIT4@NET0',
                '20HTF14AP001I.UNIT4@NET0'
]

if __name__ == '__main__':
    # ==================== 遍历文件并导入 ====================
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'res', '普安-近3月浆脱硫数据', '流畅实验数据') # 需要遍历的文件地址
    total_start = time.time()
    cnt=1
    for root, dirs, files in os.walk(file_path): # 文件夹地址 所有目录名称 所有文件名
        all_data = []
        
        for file in files:
            if file.lower().endswith('.xls'):
                full_path = os.path.join(root, file)

                try:
                    df = pd.read_excel(full_path, engine='calamine', skiprows=29) # 导入地址 xls识别引擎（必须是这个） 跳过前30行
                    df = df.dropna(axis=1, how='all') # 删除空列（合并单元格等列数据）
                    if df.empty:
                        continue
                    all_data.append(df)
                except Exception as e:
                    print(f'文件错误{full_path}:{e}')
        # ==================== 合并数据 ====================
        if all_data:
            final_df = pd.concat(all_data, ignore_index=True) # 聚合
            final_df = final_df.sort_values(by="Date Time", ascending=True).reset_index(drop=True) # 按时间排序
            final_df = final_df.drop(columns=ignore_columns, errors='ignore') # 删除不许需要的列
            final_df.rename(columns=column_mapping, inplace=True) # 重命名标题头
            final_df['Date Time'] = pd.to_datetime(
                final_df['Date Time'],
                format='%m/%d/%Y %H:%M:%S',  # 匹配原格式 01/13/2026 00:00:00
                errors='coerce'              # 异常时间设为空
            )
            final_df['Date Time'] = final_df['Date Time'].dt.strftime('%Y/%m/%d %H:%M') # 整理格式
            output_path = os.path.join(file_path, f'data{cnt}.csv')
            final_df.to_csv(output_path, index=False, encoding='utf-8-sig')
            cnt += 1

    total_time = time.time() - total_start
    print(f'累计用时:{total_time:.2f}s')

    